/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./RangeBoundDatePicker/RangeBoundDatePickerView.tsx":
/*!***********************************************************!*\
  !*** ./RangeBoundDatePicker/RangeBoundDatePickerView.tsx ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   RangeBoundDatePickerView: () => (/* binding */ RangeBoundDatePickerView)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\n/* harmony import */ var _fluentui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass RangeBoundDatePickerView extends react__WEBPACK_IMPORTED_MODULE_0__.Component {\n  constructor(props) {\n    super(props);\n    this.calendarDayProps = {\n      customDayCellRef: (element, date, classNames) => {\n        if (element) {\n          element.title = 'custom title from customDayCellRef: ' + date.toString();\n          if (this.props.disableDays.includes(date.getDay()) || this.state.normalizedRestrictedDates.includes(this.normalizeDate(date))) {\n            var dayOutsideBounds = classNames === null || classNames === void 0 ? void 0 : classNames.dayOutsideBounds;\n            dayOutsideBounds && element.classList.add(dayOutsideBounds);\n            element.children[0].disabled = true;\n          }\n        }\n      }\n    };\n    this.DateRange = (minDate, maxDate) => {\n      this.setState({\n        minDate,\n        maxDate\n      });\n    };\n    this.restrictedDates = dates => {\n      var dts = dates.map(date => this.normalizeDate(date));\n      this.setState({\n        normalizedRestrictedDates: dts\n      });\n    };\n    this.resetDatePicker = () => {\n      this.setState({\n        currentSelectedDate: this.state.initialSelectedDate\n      });\n      this.props.onSelectDate(this.state.initialSelectedDate);\n    };\n    this.state = {\n      minDate: props.minDate,\n      maxDate: props.maxDate,\n      initialSelectedDate: props.selectedDate,\n      currentSelectedDate: props.selectedDate,\n      normalizedRestrictedDates: this.props.restrictedDates.map(date => this.normalizeDate(date))\n    };\n    // Attach methods and state to the global window object so PCF can call updates\n    // eslint-disable-next-line @typescript-eslint/no-explicit-any\n    window[\"pcfDateControl_\".concat(props.uniqueKey)] = {\n      dateRange: this.DateRange,\n      restrictedDates: this.restrictedDates\n    };\n    this.updateSelectedDate = this.updateSelectedDate.bind(this);\n  }\n  normalizeDate(date) {\n    return \"\".concat(date.getFullYear(), \"-\").concat(date.getMonth(), \"-\").concat(date.getDate());\n  }\n  getDatePickerStrings() {\n    return Object.assign(Object.assign({}, _fluentui_react__WEBPACK_IMPORTED_MODULE_1__.defaultDatePickerStrings), {\n      isOutOfBoundsErrorMessage: \"Date must be between \".concat(this.state.minDate.toLocaleDateString(), \" and \").concat(this.state.maxDate.toLocaleDateString())\n    });\n  }\n  updateSelectedDate(newValue) {\n    this.props.onSelectDate(newValue);\n    this.setState({\n      currentSelectedDate: newValue !== null && newValue !== void 0 ? newValue : null\n    });\n  }\n  render() {\n    var _a;\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"div\", {\n      className: styles.container\n    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DatePicker, {\n      className: styles.datePicker,\n      placeholder: \"Select a date...\",\n      ariaLabel: \"Select a date\",\n      strings: this.getDatePickerStrings(),\n      minDate: this.state.minDate,\n      maxDate: this.state.maxDate,\n      onSelectDate: this.updateSelectedDate,\n      value: (_a = this.state.currentSelectedDate) !== null && _a !== void 0 ? _a : undefined,\n      showGoToToday: true,\n      highlightSelectedMonth: true,\n      allowTextInput: this.props.allowTextInput,\n      showMonthPickerAsOverlay: this.props.showMonthPickerAsOverlay,\n      showWeekNumbers: this.props.showWeekNumbers,\n      isRequired: this.props.isRequired,\n      disabled: this.props.isDisable,\n      calendarAs: props => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.Calendar, Object.assign({}, props, {\n        calendarDayProps: this.calendarDayProps\n      }))\n    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.DefaultButton, {\n      disabled: this.props.isDisable,\n      id: \"DefaultButton\",\n      onClick: this.resetDatePicker,\n      text: \"Revert\"\n    })));\n  }\n}\nvar styles = (0,_fluentui_react__WEBPACK_IMPORTED_MODULE_1__.mergeStyleSets)({\n  container: {\n    display: 'flex',\n    alignItems: 'baseline',\n    gap: '10px',\n    minWidth: '-webkit-fill-available'\n  },\n  datePicker: {\n    flexGrow: 1 // Allows DatePicker to take available space\n  }\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./RangeBoundDatePicker/RangeBoundDatePickerView.tsx?\n}");

/***/ }),

/***/ "./RangeBoundDatePicker/index.ts":
/*!***************************************!*\
  !*** ./RangeBoundDatePicker/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   RangeBoundDatePicker: () => (/* binding */ RangeBoundDatePicker)\n/* harmony export */ });\n/* harmony import */ var _RangeBoundDatePickerView__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RangeBoundDatePickerView */ \"./RangeBoundDatePicker/RangeBoundDatePickerView.tsx\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nclass RangeBoundDatePicker {\n  constructor() {\n    this._minDate = new Date();\n    this._maxDate = new Date();\n    this._newSelectedDate = null;\n    this._disableDays = [];\n    this._restrictedDates = [];\n    this._firstDayOfWeek = 0;\n    this.onDateSelectChange = newValue => {\n      this._newSelectedDate = newValue !== null && newValue !== void 0 ? newValue : null;\n      this.notifyOutputChanged();\n    };\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   */\n  init(context, notifyOutputChanged, _state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.synchronizeContext(context);\n  }\n  disabledDatesParse(listDates) {\n    try {\n      if (!listDates) return [];\n      var dates = listDates.split(',').map(dateStr => dateStr.trim()).filter(dateStr => dateStr.length == 10).map(dateStr => new Date(dateStr)).filter(date => !isNaN(date.getTime()));\n      return dates;\n    } catch (error) {\n      console.log(\"[RangeBoundDatePicker] disabledDatesParse error\", {\n        listDates,\n        error\n      });\n      return [];\n    }\n  }\n  dateConverter(date) {\n    var duration = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : \"\";\n    try {\n      if (!date) {\n        console.log(\"[RangeBoundDatePicker] dateConverter received empty value\", {\n          duration\n        });\n        return null;\n      }\n      if (duration === \"\") {\n        var parsed = new Date(date);\n        if (isNaN(parsed.getTime())) {\n          console.log(\"[RangeBoundDatePicker] dateConverter produced invalid Date\", {\n            date,\n            duration\n          });\n          return null;\n        }\n        return parsed;\n      }\n      var durationParts = date.split('.').map(part => part.trim()).filter(part => part.length > 0);\n      if (durationParts.length !== 3 && durationParts.length !== 4) {\n        console.log(\"[RangeBoundDatePicker] dateConverter unsupported duration format\", {\n          date,\n          duration\n        });\n        return null;\n      }\n      var years = this.isValidNumber(durationParts[0]) ? Number(durationParts[0]) : 0;\n      var months = 0;\n      var weeks = 0;\n      var days = 0;\n      if (durationParts.length === 4) {\n        months = this.isValidNumber(durationParts[1]) ? Number(durationParts[1]) : 0;\n        weeks = this.isValidNumber(durationParts[2]) ? Number(durationParts[2]) : 0;\n        days = this.isValidNumber(durationParts[3]) ? Number(durationParts[3]) : 0;\n      } else {\n        months = this.isValidNumber(durationParts[1]) ? Number(durationParts[1]) : 0;\n        days = this.isValidNumber(durationParts[2]) ? Number(durationParts[2]) : 0;\n      }\n      var adjusted = new Date();\n      adjusted.setHours(0, 0, 0, 0);\n      var weekCount = weeks > 0 ? Math.floor(weeks) : 0;\n      if (duration === \"future\") {\n        adjusted.setFullYear(adjusted.getFullYear() + years);\n        adjusted.setMonth(adjusted.getMonth() + months);\n        if (weekCount > 0) {\n          var normalizedDay = this.normalizeDayOfWeek(adjusted.getDay());\n          var daysToEndOfWeek = 6 - normalizedDay;\n          adjusted.setDate(adjusted.getDate() + daysToEndOfWeek + (weekCount - 1) * 7);\n        }\n        adjusted.setDate(adjusted.getDate() + days);\n      } else if (duration === \"past\") {\n        adjusted.setFullYear(adjusted.getFullYear() - years);\n        adjusted.setMonth(adjusted.getMonth() - months);\n        if (weekCount > 0) {\n          var _normalizedDay = this.normalizeDayOfWeek(adjusted.getDay());\n          adjusted.setDate(adjusted.getDate() - _normalizedDay - (weekCount - 1) * 7);\n        }\n        adjusted.setDate(adjusted.getDate() - days);\n      }\n      return adjusted;\n    } catch (error) {\n      console.log(\"[RangeBoundDatePicker] failed to convert date\", {\n        date,\n        duration,\n        error\n      });\n      return null;\n    }\n  }\n  isValidNumber(value) {\n    var num = Number(value);\n    return !isNaN(num) && isFinite(num);\n  }\n  normalizeDayOfWeek(day) {\n    var normalized = (day - this._firstDayOfWeek) % 7;\n    return normalized < 0 ? normalized + 7 : normalized;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   * @returns ReactElement root react element for the control\n   */\n  updateView(context) {\n    this.synchronizeContext(context);\n    var props = {\n      minDate: this._minDate,\n      maxDate: this._maxDate,\n      selectedDate: this._selectedDate,\n      onSelectDate: this.onDateSelectChange,\n      uniqueKey: this._uniqueKey,\n      allowTextInput: this._allowTextInput,\n      showMonthPickerAsOverlay: this._showMonthPickerAsOverlay,\n      showWeekNumbers: this._showWeekNumbers,\n      isRequired: this._isRequired,\n      disableDays: this._disableDays,\n      restrictedDates: this._restrictedDates,\n      isDisable: this._isDisable\n    };\n    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1__.createElement(_RangeBoundDatePickerView__WEBPACK_IMPORTED_MODULE_0__.RangeBoundDatePickerView, props);\n  }\n  synchronizeContext(context) {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;\n    var parameters = context.parameters;\n    var rawValues = {\n      dateRangeSelector: parameters.dateRangeSelector.raw,\n      minDate: parameters.minDate.raw,\n      maxDate: parameters.maxDate.raw,\n      pastTimeFrame: parameters.pastTimeFrame.raw,\n      futureTimeFrame: parameters.futureTimeFrame.raw,\n      disableDays: parameters.disableDays.raw,\n      disabledDates: parameters.disabledDates.raw,\n      allowTextInput: parameters.allowTextInput.raw,\n      showMonthPickerAsOverlay: parameters.showMonthPickerAsOverlay.raw,\n      showWeekNumbers: parameters.showWeekNumbers.raw,\n      isRequired: parameters.isRequired.raw,\n      selectedDate: parameters.DateAndTime.raw,\n      isControlDisabled: context.mode.isControlDisabled\n    };\n    console.log(\"[RangeBoundDatePicker] synchronizeContext inputs\", rawValues);\n    var userSettings = context.userSettings;\n    var weekStartCandidate = (_b = (_a = userSettings === null || userSettings === void 0 ? void 0 : userSettings.dateFormattingInfo) === null || _a === void 0 ? void 0 : _a.weekStartDay) !== null && _b !== void 0 ? _b : userSettings === null || userSettings === void 0 ? void 0 : userSettings.weekStartDay;\n    if (typeof weekStartCandidate === \"number\" && weekStartCandidate >= 0 && weekStartCandidate <= 6) {\n      this._firstDayOfWeek = weekStartCandidate;\n    }\n    this._uniqueKey = (_e = (_d = (_c = parameters.DateAndTime.attributes) === null || _c === void 0 ? void 0 : _c.LogicalName) !== null && _d !== void 0 ? _d : this._uniqueKey) !== null && _e !== void 0 ? _e : \"\";\n    this._selectedDate = (_g = (_f = parameters.DateAndTime.raw) !== null && _f !== void 0 ? _f : this._selectedDate) !== null && _g !== void 0 ? _g : new Date();\n    var selector = parameters.dateRangeSelector.raw;\n    if (selector === \"0\") {\n      var minCandidate = this.dateConverter(parameters.minDate.raw);\n      var maxCandidate = this.dateConverter(parameters.maxDate.raw);\n      this._minDate = minCandidate !== null && minCandidate !== void 0 ? minCandidate : this._minDate;\n      this._maxDate = maxCandidate !== null && maxCandidate !== void 0 ? maxCandidate : this._maxDate;\n    } else if (selector === \"1\") {\n      var _minCandidate = this.dateConverter(parameters.pastTimeFrame.raw, \"past\");\n      var _maxCandidate = this.dateConverter(parameters.futureTimeFrame.raw, \"future\");\n      this._minDate = _minCandidate !== null && _minCandidate !== void 0 ? _minCandidate : this._minDate;\n      this._maxDate = _maxCandidate !== null && _maxCandidate !== void 0 ? _maxCandidate : this._maxDate;\n    } else {\n      console.log(\"[RangeBoundDatePicker] unknown dateRangeSelector value, resetting bounds\", {\n        selector\n      });\n      this._minDate = new Date();\n      this._maxDate = new Date();\n    }\n    switch (parameters.disableDays.raw) {\n      case \"6\":\n        this._disableDays = [6];\n        break;\n      case \"0\":\n        this._disableDays = [0];\n        break;\n      case \"7\":\n        this._disableDays = [0, 6];\n        break;\n      default:\n        this._disableDays = [];\n    }\n    this._allowTextInput = (_h = parameters.allowTextInput.raw) !== null && _h !== void 0 ? _h : false;\n    this._showMonthPickerAsOverlay = (_j = parameters.showMonthPickerAsOverlay.raw) !== null && _j !== void 0 ? _j : false;\n    this._showWeekNumbers = (_k = parameters.showWeekNumbers.raw) !== null && _k !== void 0 ? _k : false;\n    this._isRequired = (_l = parameters.isRequired.raw) !== null && _l !== void 0 ? _l : false;\n    this._restrictedDates = this.disabledDatesParse((_m = parameters.disabledDates.raw) !== null && _m !== void 0 ? _m : \"\");\n    this._isDisable = context.mode.isControlDisabled;\n    console.log(\"[RangeBoundDatePicker] computed state\", {\n      minDate: this._minDate,\n      maxDate: this._maxDate,\n      disableDays: this._disableDays,\n      restrictedDates: this._restrictedDates,\n      allowTextInput: this._allowTextInput,\n      showMonthPickerAsOverlay: this._showMonthPickerAsOverlay,\n      showWeekNumbers: this._showWeekNumbers,\n      isRequired: this._isRequired,\n      isDisable: this._isDisable,\n      firstDayOfWeek: this._firstDayOfWeek\n    });\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    var _a;\n    return {\n      DateAndTime: (_a = this._newSelectedDate) !== null && _a !== void 0 ? _a : undefined\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./RangeBoundDatePicker/index.ts?\n}");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!***************************!*\
  !*** external "Reactv16" ***!
  \***************************/
/***/ ((module) => {

module.exports = Reactv16;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./RangeBoundDatePicker/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('sa.RangeBoundDatePicker', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.RangeBoundDatePicker);
} else {
	var sa = sa || {};
	sa.RangeBoundDatePicker = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.RangeBoundDatePicker;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}